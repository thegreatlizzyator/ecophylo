# EcoPhylo

project description

The source for this project is available [here][src].

Provide a link to full documentation tutorial [here][tutorial]. 

----

Publications using this package here. 

[src]: https://github.com/thegreatlizzyator/ecophylo

To install this package, wait for it to be finished
```shell
pip install path_to/the_great.tar.gz
```
